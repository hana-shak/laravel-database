<?php $__env->startSection('title'); ?>
<?php echo e($arrsingle['name']); ?>'s| Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/single_student.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

<div class="col card m-3 " style="width: 18rem;">
    <img class="card-img-top" src="<?php echo e($arrsingle['image']); ?>" alt="Card image cap">
    <div class="card-body d-flex flex-column">
      <h5 class="card-title"><?php echo e($arrsingle['name']); ?></h5>
       <p><?php echo e($arrsingle['birthday']); ?></p>
       <p><a href="<?php echo e($arrsingle['github_account']); ?>">Github Account</a></p>
       <p><a href="<?php echo e($arrsingle['linkedin']); ?>">LinkedIn Account</a></p>

       <?php $__currentLoopData = $arrsingle['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($projectname['completed']): ?>

                <li class=""> <i class="fa fa-chevron-circle-right" aria-hidden="true"></i><?php echo e($projectname['project_name']); ?></li>

                <?php else: ?>

                <li class=""> <i class="fa fa-chevron-circle-right text-danger" aria-hidden="true"></i><?php echo e($projectname['project_name']); ?></li>

            <?php endif; ?>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-mini-first\students\resources\views/students/singlestudent.blade.php ENDPATH**/ ?>