<?php $__env->startSection('title'); ?>
Registration
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>

<form action="/customertable" method="post">

    <div class="form-group">
        <label for="exampleInputEmail1">Name</label>
        <input type="text" class="form-control" id="exampleInputEmail1" name="name" placeholder="Enter name">
         <div> <?php echo e($errors->first('name')); ?></div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Email address</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
        <div><?php echo e($errors->first('email')); ?> </div>
    </div>


    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" name="password" placeholder="Password">
      <div><?php echo e($errors->first('password')); ?></div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Mobile</label>
        <input type="number" class="form-control" id="exampleInputEmail1" name="phone" placeholder="Enter mobile number">
        <div><?php echo e($errors->first('phone')); ?></div>
     </div>

    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
    <?php echo csrf_field(); ?>

  </form>
  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-mini-first\students\resources\views/students/register.blade.php ENDPATH**/ ?>