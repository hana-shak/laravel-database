<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row mt-5">
<?php $__currentLoopData = $arrstudent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-2 card m-3 " style="width: 18rem;">
    <img class="card-img-top" src="<?php echo e($students['image']); ?>" alt="Card image cap">
    <div class="card-body d-flex flex-column">
      <h5 class="card-title"><?php echo e($students['name']); ?></h5>
      <a href="singlestudent/<?php echo e($key); ?>" class="mt-auto btn btn-warning btn-sm d-flex justify-content-center">View Profile</a>
    </div>
  </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-mini-first\students\resources\views/students/index.blade.php ENDPATH**/ ?>