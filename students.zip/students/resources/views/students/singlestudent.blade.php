@extends('layouts.master')

@section('title')
{{$arrsingle['name']}}'s| Profile
@endsection
@section('head')
<link rel="stylesheet" href="{{ URL::asset('css/single_student.css') }}" />
@endsection
@section('main')

<div class="col card m-3 " style="width: 18rem;">
    <img class="card-img-top" src="{{$arrsingle['image']}}" alt="Card image cap">
    <div class="card-body d-flex flex-column">
      <h5 class="card-title">{{$arrsingle['name']}}</h5>
       <p>{{$arrsingle['birthday']}}</p>
       <p><a href="{{$arrsingle['github_account']}}">Github Account</a></p>
       <p><a href="{{$arrsingle['linkedin']}}">LinkedIn Account</a></p>

       @foreach ($arrsingle['projects'] as $projectname)

            @if($projectname['completed'])

                <li class=""> <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>{{ $projectname['project_name']}}</li>

                @else

                <li class=""> <i class="fa fa-chevron-circle-right text-danger" aria-hidden="true"></i>{{ $projectname['project_name']}}</li>

            @endif

       @endforeach
    </div>
  </div>
@endsection
