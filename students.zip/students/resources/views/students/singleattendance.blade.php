@extends('layouts.master')

@section('title')
{{$arrstudent['name']}} attendance record
@endsection

@section('main')
<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
<table class="table mt-5">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Day Date</th>
        <th scope="col">Check-In</th>
        <th scope="col">Check-Out</th>
        <th scope="col">Work hrs</th>
      </tr>
    </thead>
    <tbody>
        @php
             foreach($arrstudent['attendance'] as $attend)
             {
                 $day       = substr($attend['check_in'], 0,6);
                 $check_in  = intval(substr($attend['check_in'], -5,2));
                 $check_out = intval(substr($attend['check_out'], -5,2));
                 $total_hrs = $check_out - $check_in;

                 if($total_hrs < 8)
                 {
                    echo"<tr class='table-danger'>";
                    echo"<td> $day</td>";
                    echo"<td>$check_in</td>";
                    echo"<td> $check_out</td>";
                    echo"<td> $total_hrs </td>";
                    echo"</tr>";

                 }else
                 {
                    echo"<tr class='table-success'>";
                    echo"<td> $day</td>";
                    echo"<td>$check_in</td>";
                    echo"<td> $check_out</td>";
                    echo"<td> $total_hrs </td>";
                    echo"</tr>";
                   }


             }
        @endphp





    </tbody>
</table>
</div>
<div class="col-md-3"></div>
</div>




@endsection
