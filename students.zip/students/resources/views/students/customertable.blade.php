@extends('layouts.master')

@section('title')
Registered Customers
@endsection

@section('main')

<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
<table class="table mt-5">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone</th>
      </tr>
    </thead>
    <tbody>
        @foreach ($users as $user)
            <tr>
               <td>{{$user->id}}</td>
               <td>{{$user->name}}</td>
               <td>{{$user->email}}</td>
               <td>{{$user->phone}}</td>
            </tr>
        @endforeach


       {{-- {{THIS ONLY TO SHOW DATA WITHOUT DB - 1st step}} --}}
                   {{-- <tr class='table-danger'>
                   <td>{{$infoarr[0]}}</td>
                   <td>{{$infoarr[1]}}</td>
                   <td>{{$infoarr[2]}}</td>

                   </tr>; --}}
    </tbody>
</table>
</div>
<div class="col-md-3"></div>
</div>
@endsection

