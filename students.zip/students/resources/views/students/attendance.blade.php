@extends('layouts.master')

@section('title')
Students Attendance
@endsection

@section('main')
Students Attendance

<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
<table class="table mt-5">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Student Name</th>
        <th scope="col">Attendance Record</th>
        {{-- <th scope="col">Check-out</th>
        <th scope="col">Handle</th> --}}
      </tr>
    </thead>
    <tbody>
      @foreach ($arrstudent as $students)
      <tr>
          <td>{{$students['name']}}</td>
          <td><a href="singleattendance/{{$students['id']}}">Attendance</a></td>
      </tr>
      @endforeach

    </tbody>
</table>
</div>
<div class="col-md-3"></div>
</div>
@endsection
