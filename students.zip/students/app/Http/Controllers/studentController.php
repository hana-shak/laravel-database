<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class studentController extends Controller
{
    /**
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //to return to index page
        $arrstudent = $this->students_array();
        return view ('students.index', compact('arrstudent'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function profile($id)
    {
        $arrsingle = $this->students_array()[$id];
        return view ('students.singlestudent', compact('arrsingle'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function attendance()
    {
        //All student table to for others
        $arrstudent = $this->students_array();
        return view ('students.attendance', compact('arrstudent'));
    }

    public function singleattendance($id)
    {
        //All student table to for others
        $arrstudent = $this->students_array()[$id];
        return view ('students.singleattendance', compact('arrstudent'));
    }

    public function gallery()
    {
        $arrpic = $this->pictures();
        return view ('students.gallery', compact('arrpic'));
    }


    //This finction to put array inside it, to retrive it
    public function students_array()
    {
        $students =
            array(
                array(
                    "id"                => 1,
                    "name"              => "Adam Abusamra",
                    "birthday"          => "25/10/2001",
                    "github_account"    => "https://github.com/adamabusamra/",
                    "linkedin"          => "https://www.linkedin.com/in/adam-abusamra/",
                    "image"             => "https://media-exp1.licdn.com/dms/image/C4E03AQEqFtVHK9XbbA/profile-displayphoto-shrink_400_400/0/1605016049903?e=1613606400&v=beta&t=EP_-Ib56NEZ854P9kAvY-d62gfiFxGyHqB5QOrY4u_I",
                    "projects"          => array(
                        array(
                            "project_name" => "Personal Portfolio",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Dynamic Website JS",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Wordpress Website",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "PHP e-commerce dynamic site",
                            "completed" => 1
                        )
                    ),
                    "attendance" => array(
                        array(
                            "check_in"      => "Dec 13, 2020, 09:00",
                            "check_out"     => "Dec 13, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 14, 2020, 09:00",
                            "check_out"     => "Dec 14, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 15, 2020, 09:00",
                            "check_out"     => "Dec 15, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 16, 2020, 09:00",
                            "check_out"     => "Dec 16, 2020, 16:00"
                        ),
                        array(
                            "check_in"      => "Dec 17, 2020, 09:00",
                            "check_out"     => "Dec 17, 2020, 17:00"
                        )
                    )
                ),
                array(
                    "id"                => 2,
                    "name"              => "Mohammad Yaqoub",
                    "birthday"          => "12/2/1996",
                    "github_account"    => "https://github.com/MohYacoub",
                    "linkedin"          => "https://www.linkedin.com/in/mohammadyacoub",
                    "image"             => "https://media-exp1.licdn.com/dms/image/C4E03AQFivRZGiqQABg/profile-displayphoto-shrink_400_400/0/1600874534239?e=1613606400&v=beta&t=l_fLB7ANsSErGURvnN4JB2d-4AdOCRisftf6yro5rsc",
                    "projects"          => array(
                        array(
                            "project_name" => "Personal Portfolio",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Dynamic Website JS",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Wordpress Website",
                            "completed" => 0
                        ),
                        array(
                            "project_name" => "PHP e-commerce dynamic site",
                            "completed" => 1
                        )
                    ),
                    "attendance" => array(
                        array(
                            "check_in"      => "Dec 13, 2020, 09:00",
                            "check_out"     => "Dec 13, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 14, 2020, 09:00",
                            "check_out"     => "Dec 14, 2020, 15:00"
                        ),
                        array(
                            "check_in"      => "Dec 15, 2020, 09:00",
                            "check_out"     => "Dec 15, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 16, 2020, 09:00",
                            "check_out"     => "Dec 16, 2020, 18:00"
                        ),
                        array(
                            "check_in"      => "Dec 17, 2020, 09:00",
                            "check_out"     => "Dec 17, 2020, 17:00"
                        )
                    )
                ),
                array(
                    "id"                => 3,
                    "name"              => "Sadi Ashlaq",
                    "birthday"          => "13/12/1997",
                    "github_account"    => "https://github.com/sadi/",
                    "linkedin"          => "www.linkedin.com/in/sadi-ashlaq",
                    "image"             => "https://media-exp1.licdn.com/dms/image/C5603AQFFXBi-puYdKg/profile-displayphoto-shrink_400_400/0/1600854238228?e=1613606400&v=beta&t=DC3_A8DP0DmD_LsFJj7rsht9So2SkuoPPJlnYnjPddE",
                    "projects"          => array(
                        array(
                            "project_name" => "Personal Portfolio",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Dynamic Website JS",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Wordpress Website",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "PHP e-commerce dynamic site",
                            "completed" => 1
                        )
                    ),
                    "attendance" => array(
                        array(
                            "check_in"      => "Dec 13, 2020, 09:00",
                            "check_out"     => "Dec 13, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 14, 2020, 11:00",
                            "check_out"     => "Dec 14, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 15, 2020, 09:00",
                            "check_out"     => "Dec 15, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 16, 2020, 09:00",
                            "check_out"     => "Dec 16, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 17, 2020, 09:00",
                            "check_out"     => "Dec 17, 2020, 17:00"
                        )
                    )
                ),
                array(
                    "id"                => 4,
                    "name"              => "Firas Diab",
                    "birthday"          => "25/10/2001",
                    "github_account"    => "https://github.com/firas-diab/",
                    "linkedin"          => "www.linkedin.com/in/firas",
                    "image"             => "https://scontent.famm7-1.fna.fbcdn.net/v/t31.0-8/22770834_1634613739932801_7646243513244540913_o.jpg?_nc_cat=101&ccb=2&_nc_sid=174925&_nc_eui2=AeGOcYRsSwDrFKey8cfNGmvd6Ehid6hww9_oSGJ3qHDD3yWivE52_jnDus66lfQNhQpaycf3Ep-K571yws0NsIY1&_nc_ohc=rVg785R0bT8AX_bXw91&_nc_ht=scontent.famm7-1.fna&oh=45900ad2326ba370d219467eeb0396d6&oe=6000714D",
                    "projects"          => array(
                        array(
                            "project_name" => "Personal Portfolio",
                            "completed" => 0
                        ),
                        array(
                            "project_name" => "Dynamic Website JS",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Wordpress Website",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "PHP e-commerce dynamic site",
                            "completed" => 1
                        )
                    ),
                    "attendance" => array(
                        array(
                            "check_in"      => "Dec 13, 2020, 09:00",
                            "check_out"     => "Dec 13, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 14, 2020, 09:00",
                            "check_out"     => "Dec 14, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 15, 2020, 08:00",
                            "check_out"     => "Dec 15, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 16, 2020, 09:00",
                            "check_out"     => "Dec 16, 2020, 16:00"
                        ),
                        array(
                            "check_in"      => "Dec 17, 2020, 09:00",
                            "check_out"     => "Dec 17, 2020, 17:00"
                        )
                    )
                ),
                array(
                    "id"                => 5,
                    "name"              => "Omar Alnawaisah",
                    "birthday"          => "13/05/1998",
                    "github_account"    => "https://github.com/omar-alnawaysah/",
                    "linkedin"          => "www.linkedin.com/in/omar-nawaysah",
                    "image"             => "https://ca.slack-edge.com/T01ANQW3AK0-U01BD2N7VQD-863e6442f94f-512",
                    "projects"          => array(
                        array(
                            "project_name" => "Personal Portfolio",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Dynamic Website JS",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "Wordpress Website",
                            "completed" => 1
                        ),
                        array(
                            "project_name" => "PHP e-commerce dynamic site",
                            "completed" => 1
                        )
                    ),
                    "attendance" => array(
                        array(
                            "check_in"      => "Dec 13, 2020, 09:00",
                            "check_out"     => "Dec 13, 2020, 02:00"
                        ),
                        array(
                            "check_in"      => "Dec 14, 2020, 09:00",
                            "check_out"     => "Dec 14, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 15, 2020, 09:00",
                            "check_out"     => "Dec 15, 2020, 17:00"
                        ),
                        array(
                            "check_in"      => "Dec 16, 2020, 09:00",
                            "check_out"     => "Dec 16, 2020, 16:00"
                        ),
                        array(
                            "check_in"      => "Dec 17, 2020, 09:00",
                            "check_out"     => "Dec 17, 2020, 17:00"
                        )
                    )
                ),
            );

        return $students;
    }

    public function pictures()
    {
        $oca_pics = ["https://www.orange.jo/sites/Press/EN/PublishingImages/coding-academy-news.jpg",
                     'https://scontent.famm6-1.fna.fbcdn.net/v/t1.0-9/131380820_451243482929991_6924644990890441029_o.jpg?_nc_cat=101&ccb=2&_nc_sid=730e14&_nc_eui2=AeHQAI8j3X8dbxG1u9GVmARh9d0FmCH-DOT13QWYIf4M5F2rfa_RQW3TfKM5OnUZuBzQufR_LUEUZQHcOE1gz5v-&_nc_ohc=MK1W9afENRwAX9vRBde&_nc_ht=scontent.famm6-1.fna&oh=ad803b546183dd8dc560131e7634e8da&oe=6002C4D7',
                     'https://scontent.famm6-1.fna.fbcdn.net/v/t1.0-9/131006530_451243469596659_1191014358476718751_o.jpg?_nc_cat=111&ccb=2&_nc_sid=730e14&_nc_eui2=AeHtUKn9XwnqprTQiSTZDd2rGoBa5Dv06zAagFrkO_TrMFMVXLYis56lnt33ShB-WrE7QgLccsjh9wNAoNBVaUoa&_nc_ohc=R3JFeO81IG0AX92yutk&_nc_ht=scontent.famm6-1.fna&oh=72d3a0d8e7b892fc95186247aeeff11b&oe=60033907',
                     'https://scontent.famm6-1.fna.fbcdn.net/v/t1.0-9/128893198_443762040344802_794913794965168780_n.jpg?_nc_cat=104&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeGwGpQ_XSMixWWO946-snrVjMJNgHLzWVmMwk2AcvNZWV9sXSPh2z8h5HaGvSN_meF2B73t13-JWQaV7ssmVCv9&_nc_ohc=am4yi-zlSpwAX_cTZ6E&_nc_ht=scontent.famm6-1.fna&oh=b2ebe819169b5d5df04a034585431fd3&oe=60042D65'];

                     return $oca_pics;

                    }

}
