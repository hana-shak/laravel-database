<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class CustomerController extends Controller
{

    // public function list(Request $request)
    // {
    //    return view('students.register');
    // }

    // public function store()
    // {

    //     $data = request()->validate([
    //         'name'     =>'required',
    //         'email'    =>'required|email',
    //         'password' =>'required|min:8|max:16',
    //         'phone'    =>'required|digits:14'
    // ]);
    //     $customer = new User;
    //      $customer->name request('name');
    //     $y = request('email');
    //     $z = request('phone');
    //     $infoarr=array();
    //     $infoarr=[$x,$y,$z];
    //     // dd($infoarr);
    //     return view('students.customertable',["infoarr"=>$infoarr]);
    // }

    public function show()
    {
       return view('students.register');
    }
    public function list()
    {
        $users = User::all();
        return view ('students.customertable',
                     ['users'=>$users]

        );

    }
    public function insert(Request $request)
    {

        $this->validate($request, [
                    'name'     =>'required',
                    'email'    =>'required|email',
                    'password' =>'required|min:8|max:16',
                    'phone'    =>'required|digits:14']);

        $user = new User();

        $user->name      = $request->input('name');
        $user->email     = $request->input('email');
        $user->password  = $request->input('password');
        $user->phone     = $request->input('phone');

        $user->save();

        return redirect('/table');  //like header location 
        // return back();
        // return view('students.customertable');
        // return view('students.customertable',);
        // return redirect('customertable');
    }




}
